"""
Blind Assistant - A real-time object detection and spatial awareness system
for visually impaired individuals.
"""

from . import camera
from . import vision
from . import audio

__version__ = '0.1.0'
__author__ = 'Blind Assistant Team'

__all__ = ['camera', 'vision', 'audio']