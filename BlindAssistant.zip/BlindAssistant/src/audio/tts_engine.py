import pyttsx3
import logging
from typing import List, Dict, Optional
import yaml
from queue import PriorityQueue
from threading import Thread, Event
import time
import platform
import sys

logger = logging.getLogger(__name__)

class AudioManager:
    """Manages text-to-speech and audio feedback for the system."""
    
    def __init__(self, config_path: str = "config/settings.yaml"):
        """Initialize the audio manager with configuration."""
        self.config = self._load_config(config_path)
        self.audio_config = self.config["audio"]
        
        # Initialize TTS engine with error checking
        self.engine = self._initialize_tts_engine()
        if not self.engine:
            raise RuntimeError("Failed to initialize text-to-speech engine")
            
        self.configure_engine()
        
        # Test the audio system
        if not self._test_audio_system():
            raise RuntimeError("Audio system test failed")
        
        # Message queue for priority-based announcements
        self.message_queue = PriorityQueue()
        self.last_announcement_time = 0
        self.last_message = None
        self.consecutive_same_message = 0
        self.is_speaking = False
        self.stop_event = Event()
        
        # Start the announcement thread
        self.announcement_thread = Thread(target=self._announcement_worker, daemon=True)
        self.announcement_thread.start()
        
        logger.info("Audio Manager initialized successfully")

    def _initialize_tts_engine(self) -> Optional[pyttsx3.Engine]:
        """Initialize the text-to-speech engine with proper error handling."""
        try:
            logger.info("Initializing text-to-speech engine...")
            
            # Force initialization with specific driver
            if platform.system() == 'Windows':
                engine = pyttsx3.init('sapi5')
            elif platform.system() == 'Darwin':  # macOS
                engine = pyttsx3.init('nsss')
            else:  # Linux and others
                engine = pyttsx3.init('espeak')

            # Set lower latency properties
            engine.setProperty('rate', 180)  # Slightly faster default rate
            engine.setProperty('volume', 1.0)  # Full volume
            
            # Get available voices
            voices = engine.getProperty('voices')
            logger.info(f"Found {len(voices)} available voices")
            
            return engine
        except Exception as e:
            logger.error(f"Failed to initialize TTS engine: {e}")
            return None

    def _test_audio_system(self) -> bool:
        """Test the audio system by attempting to speak a test message."""
        try:
            logger.info("Testing audio system...")
            test_message = "Audio system initialized"
            
            # Try direct synchronous output
            self.engine.say(test_message)
            self.engine.runAndWait()
            
            logger.info("Audio system test successful")
            return True
        except Exception as e:
            logger.error(f"Audio system test failed: {e}")
            return False

    def _load_config(self, config_path: str) -> dict:
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
                
            # Set reasonable defaults for announcement interval
            if 'audio' not in config:
                config['audio'] = {}
            if 'announcement_interval' not in config['audio']:
                config['audio']['announcement_interval'] = 0.5  # Reduced from 2.0
                
            return config
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise

    def configure_engine(self) -> None:
        """Configure the TTS engine with settings from config."""
        try:
            # Set new properties
            self.engine.setProperty('rate', self.audio_config.get("voice_rate", 180))
            self.engine.setProperty('volume', self.audio_config.get("volume", 1.0))
            
            # Get available voices
            voices = self.engine.getProperty('voices')
            
            # Try to set preferred language
            voice_set = False
            for voice in voices:
                if self.audio_config["language"] in voice.languages or 'en' in str(voice.languages).lower():
                    self.engine.setProperty('voice', voice.id)
                    voice_set = True
                    logger.info(f"Set voice to: {voice.name}")
                    break
            
            if not voice_set:
                logger.warning(f"Could not find voice for language {self.audio_config['language']}, using default")
            
            # Test the configuration
            self.engine.say("Audio configuration complete")
            self.engine.runAndWait()
            
        except Exception as e:
            logger.error(f"Failed to configure TTS engine: {e}")
            raise

    def format_distance(self, meters: float) -> str:
        """Format distance according to configured unit."""
        try:
            if self.audio_config["distance_unit"] == "feet":
                feet = meters * 3.28084
                if feet < 1:
                    return "less than a foot"
                elif feet < 2:
                    return "one foot"
                else:
                    return f"{int(feet)} feet"
            else:
                if meters < 1:
                    return f"{int(meters * 100)} centimeters"
                else:
                    return f"{meters:.1f} meters"
        except Exception as e:
            logger.error(f"Error formatting distance: {e}")
            return "unknown distance"

    def _get_cardinal_direction(self, position: str) -> str:
        """Convert position to more natural direction."""
        if position == "center":
            return "directly ahead"
        return f"to your {position}"

    def format_detection_message(self, detection: Dict) -> str:
        """Format detection information into a spoken message."""
        try:
            obj_class = detection['class']
            distance = self.format_distance(detection['depth'])
            direction = self._get_cardinal_direction(detection['position'])
            
            # Format message based on position
            if direction == "directly ahead":
                message = f"{obj_class} {distance} away {direction}"
            else:
                message = f"{obj_class} {direction}, {distance} away"
            
            return message
            
        except Exception as e:
            logger.error(f"Error formatting detection message: {e}")
            return f"Object detected {detection.get('position', 'nearby')}"

    def queue_announcement(self, message: str, priority: int = 1) -> None:
        """Queue a message for announcement."""
        try:
            # Skip if it's the same as the last message
            if message == self.last_message:
                self.consecutive_same_message += 1
                if self.consecutive_same_message > 3:  # Skip after 3 repeats
                    return
            else:
                self.consecutive_same_message = 0
                self.last_message = message
            
            # Add timestamp to maintain FIFO order for same priority
            timestamp = time.time()
            self.message_queue.put((priority, timestamp, message))
        except Exception as e:
            logger.error(f"Failed to queue announcement: {e}")

    def announce_detections(self, detections: List[Dict]) -> None:
        """Process and announce detected objects."""
        try:
            if not detections:
                return
                
            # Process each detection
            for i, detection in enumerate(detections):
                message = self.format_detection_message(detection)
                # Higher priority for closer objects
                priority = detection['depth'] * 0.1  # Lower depth = higher priority
                self.queue_announcement(message, priority)
                
        except Exception as e:
            logger.error(f"Error announcing detections: {e}")

    def _announcement_worker(self) -> None:
        """Worker thread for processing and speaking announcements."""
        while not self.stop_event.is_set():
            try:
                current_time = time.time()
                # Reduced waiting time for more responsive announcements
                if (current_time - self.last_announcement_time < 
                    self.audio_config.get("announcement_interval", 0.5)):
                    time.sleep(0.1)
                    continue
                
                try:
                    # Get all available messages
                    latest_message = None
                    latest_priority = float('inf')
                    while not self.message_queue.empty():
                        priority, timestamp, message = self.message_queue.get_nowait()
                        if priority < latest_priority:  # Lower number = higher priority
                            latest_priority = priority
                            latest_message = message
                    if latest_message is None: continue
                    
                    # Speak the message
                    self.is_speaking = True
                    self.engine.say(latest_message)
                    self.engine.runAndWait()
                    self.is_speaking = False
                    
                    self.last_announcement_time = time.time()
                    
                except:
                    time.sleep(0.1)
                    continue
                
            except Exception as e:
                logger.error(f"Error in announcement worker: {e}")
                time.sleep(0.5)  # Reduced retry delay

    def speak_system_status(self, message: str) -> None:
        """Immediately speak a system status message."""
        try:
            logger.info(f"System status: {message}")
            # Speak directly for immediate feedback
            self.engine.say(message)
            self.engine.runAndWait()
        except Exception as e:
            logger.error(f"Failed to speak system status: {e}")

    def cleanup(self) -> None:
        """Clean up resources and stop the announcement thread."""
        self.stop_event.set()
        if self.announcement_thread.is_alive():
            self.announcement_thread.join(timeout=2.0)
        
        # Stop any ongoing speech
        if self.is_speaking:
            try:
                self.engine.stop()
            except Exception as e:
                logger.error(f"Error stopping speech: {e}")

    def __enter__(self):
        """Context manager enter."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.cleanup()