import cv2
import numpy as np
from typing import Tuple, Optional
import yaml
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class CameraManager:
    """Manages camera operations including capture and depth estimation."""
    
    def __init__(self, config_path: str = "config/settings.yaml"):
        """Initialize camera manager with configuration."""
        self.config = self._load_config(config_path)
        self.camera_config = self.config["camera"]
        
        self.cap = None
        self.frame_count = 0
        self.initialize_camera()

    def _load_config(self, config_path: str) -> dict:
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise

    def initialize_camera(self) -> None:
        """Initialize the camera device."""
        try:
            # Handle different camera device types
            device_id = self.camera_config["device_id"]
            if isinstance(device_id, str):
                # IP camera or video file
                self.cap = cv2.VideoCapture(device_id)
            else:
                # Local camera device
                self.cap = cv2.VideoCapture(device_id, cv2.CAP_DSHOW)  # Use DirectShow on Windows
            
            # Configure camera settings
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.camera_config["width"])
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.camera_config["height"])
            self.cap.set(cv2.CAP_PROP_FPS, self.camera_config["fps"])
            
            if not self.cap.isOpened():
                raise RuntimeError("Failed to open camera device")
                
            logger.info("Camera initialized successfully")
            
            # Verify camera settings
            actual_width = self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)
            actual_height = self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            actual_fps = self.cap.get(cv2.CAP_PROP_FPS)
            
            logger.info(f"Camera settings - Width: {actual_width}, Height: {actual_height}, FPS: {actual_fps}")
            
        except Exception as e:
            logger.error(f"Failed to initialize camera: {e}")
            raise

    def read_frame(self) -> Tuple[bool, Optional[np.ndarray]]:
        """Read a frame from the camera."""
        if self.cap is None:
            return False, None

        try:
            ret, frame = self.cap.read()
            if not ret:
                logger.warning("Failed to capture frame")
                return False, None

            self.frame_count += 1
            return True, frame

        except Exception as e:
            logger.error(f"Error capturing frame: {e}")
            return False, None

    def get_frame_dimensions(self) -> Tuple[int, int]:
        """Get the dimensions of the camera frame."""
        if self.cap is None:
            return (0, 0)
            
        width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        return width, height

    def estimate_depth(self, frame: np.ndarray) -> np.ndarray:
        """
        Estimate depth from frame.
        In a real implementation, this would use stereo cameras or depth sensors.
        """
        # TODO: Implement actual depth estimation
        # For now, return a mock depth map
        height, width = frame.shape[:2]
        mock_depth = np.zeros((height, width), dtype=np.float32)
        # Create a simple gradient for visualization
        mock_depth = np.indices((height, width))[1].astype(np.float32) / width * 10
        return mock_depth

    def process_frame(self, frame: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Process the captured frame and estimate depth."""
        # Basic preprocessing
        # Keep frame in BGR for OpenCV display, YOLO handles BGR input correctly
        processed_frame = frame.copy()
        depth_map = self.estimate_depth(processed_frame)
        
        return processed_frame, depth_map

    def release(self) -> None:
        """Release the camera resources."""
        if self.cap is not None:
            try:
                self.cap.release()
                logger.info("Camera resources released")
            except Exception as e:
                logger.error(f"Error releasing camera resources: {e}")

    def __enter__(self):
        """Context manager enter."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.release()