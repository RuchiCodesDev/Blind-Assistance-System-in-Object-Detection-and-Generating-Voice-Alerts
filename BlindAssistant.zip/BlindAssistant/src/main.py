import logging
import sys
from pathlib import Path
import yaml
from threading import Event
import argparse
import signal
import platform
import subprocess

# Configure logging first
def setup_logging(debug: bool = False):
    """Configure logging with optional debug mode."""
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger(__name__)

logger = None  # Will be initialized in main()

# Try to import OpenCV
try:
    import cv2
    import numpy as np
    HAS_GUI = True
except ImportError as e:
    logger = setup_logging()
    logger.error("""
Failed to import OpenCV (cv2). Please try reinstalling with:
pip uninstall opencv-python opencv-python-headless
pip install opencv-python-headless

If the issue persists, you can run the system without GUI:
python src/main.py --no-gui
""")
    HAS_GUI = False
    if '--no-gui' not in sys.argv:
        sys.exit(1)

from camera.capture import CameraManager
from vision.detector import ObjectDetector
from audio.tts_engine import AudioManager

def check_audio_capability():
    """Check if system audio is available and properly configured."""
    try:
        import pyttsx3
        engine = pyttsx3.init()
        voices = engine.getProperty('voices')
        if not voices:
            logger.error("No text-to-speech voices found on the system")
            return False
        engine.stop()
        del engine
        return True
    except ImportError:
        logger.error("pyttsx3 not installed. Please install it using: pip install pyttsx3")
        return False
    except Exception as e:
        logger.error(f"Error checking audio capability: {e}")
        return False

def check_requirements() -> bool:
    """Check if all required files and directories exist."""
    try:
        # Check config directory and file
        if not Path("config/settings.yaml").exists():
            logger.error("Configuration file not found: config/settings.yaml")
            return False

        # Check weights directory and model file
        weights_dir = Path("weights")
        if not weights_dir.exists():
            logger.error("""
YOLO model weights not found. Please:
1. Create a 'weights' directory
2. Download YOLOv8n weights using:
   wget https://github.com/ultralytics/assets/releases/download/v0.0.0/yolov8n.pt -O weights/yolov8n.pt
Or manually download from: https://github.com/ultralytics/assets/releases/download/v0.0.0/yolov8n.pt
""")
            return False

        model_file = weights_dir / "yolov8n.pt"
        if not model_file.exists():
            logger.error("""
YOLO model file not found: weights/yolov8n.pt
Please download YOLOv8n weights using:
wget https://github.com/ultralytics/assets/releases/download/v0.0.0/yolov8n.pt -O weights/yolov8n.pt
Or manually download from: https://github.com/ultralytics/assets/releases/download/v0.0.0/yolov8n.pt
""")
            return False

        # Check audio capability
        logger.info("Checking audio system...")
        if not check_audio_capability():
            return False

        logger.info("All requirements satisfied")
        return True

    except Exception as e:
        logger.error(f"Error checking requirements: {e}")
        return False

class BlindAssistant:
    """Main class for the Blind Assistant application."""
    
    def __init__(self, config_path: str = "config/settings.yaml", show_gui: bool = True):
        """Initialize the Blind Assistant system."""
        self.config = self._load_config(config_path)
        self.system_config = self.config["system"]
        self.show_gui = show_gui and HAS_GUI
        
        # Log system information
        self._log_system_info()
        
        # Initialize components with startup messages
        logger.info("Initializing audio system...")
        self.audio = AudioManager(config_path)
        self.audio.speak_system_status("Initializing camera system")
        
        logger.info("Initializing camera system...")
        self.camera = CameraManager(config_path)
        
        logger.info("Loading object detection model...")
        self.audio.speak_system_status("Loading object detection model")
        self.detector = ObjectDetector(config_path)
        
        logger.info("Configuring audio feedback system...")
        self.audio.speak_system_status("Audio system ready")
        
        self.stop_event = Event()
        self.frame_skip = self.system_config["frame_skip"]
        self.frame_count = 0
        
        # Set up signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        if self.show_gui:
            try:
                # Create window for display
                cv2.namedWindow('Blind Assistant Detection', cv2.WINDOW_NORMAL)
                logger.info("GUI window initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize GUI window: {e}")
                self.show_gui = False
                logger.info("Continuing without GUI...")

    def _log_system_info(self):
        """Log system information for debugging."""
        logger.debug("System Information:")
        logger.debug(f"Platform: {platform.system()} {platform.release()}")
        logger.debug(f"Python version: {platform.python_version()}")
        if HAS_GUI:
            logger.debug(f"OpenCV version: {cv2.__version__}")
        logger.debug(f"Working directory: {Path.cwd()}")

    def _load_config(self, config_path: str) -> dict:
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise

    def _signal_handler(self, signum, frame):
        """Handle shutdown signals."""
        logger.info(f"Received signal {signum}, initiating shutdown...")
        self.stop_event.set()

    def draw_detection_info(self, frame: np.ndarray, detections: list) -> np.ndarray:
        """Draw detection information on the frame."""
        if not self.show_gui:
            return frame
            
        try:
            display_frame = frame.copy()
            
            for detection in detections:
                box = detection['box']
                conf = detection['confidence']
                label = f"{detection['class']} ({detection['depth']:.1f}m) {conf:.2f}"
                position = detection['position']
                
                # Convert box coordinates to integers
                box = [int(x) for x in box]
                
                # Draw bounding box
                color = (0, 255, 0)  # Green
                cv2.rectangle(display_frame, (box[0], box[1]), (box[2], box[3]), color, 2)
                
                # Add filled background for text
                text_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2)[0]
                cv2.rectangle(display_frame, 
                             (box[0], box[1] - text_size[1] - 4),
                             (box[0] + text_size[0], box[1]),
                             color, -1)
                
                # Draw label
                cv2.putText(display_frame, label,
                           (box[0], box[1] - 5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2)
                
                # Draw direction indicator
                center_x = (box[0] + box[2]) // 2
                center_y = (box[1] + box[3]) // 2
                direction_text = f"Position: {position}"
                cv2.putText(display_frame, direction_text,
                           (center_x - 60, center_y),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            
            return display_frame
        except Exception as e:
            logger.error(f"Error drawing detection info: {e}")
            return frame

    def process_frame(self):
        """Process a single frame from the camera."""
        # Capture frame
        ret, frame = self.camera.read_frame()
        if not ret:
            return False

        # Skip frames if configured
        self.frame_count += 1
        if self.frame_count % self.frame_skip != 0:
            return True

        # Process frame
        try:
            # Get processed frame and depth map
            processed_frame, depth_map = self.camera.process_frame(frame)
            
            # Detect objects
            detections = self.detector.process_frame(processed_frame, depth_map)
            
            # Log detection summary
            if detections:
                logger.debug(f"Detected {len(detections)} objects in frame {self.frame_count}")
                # Announce detections
                self.audio.announce_detections(detections)
            
            # Update display if GUI is enabled
            if self.show_gui:
                try:
                    display_frame = self.draw_detection_info(frame, detections)
                    # Resize window to a reasonable size
                    cv2.resizeWindow('Blind Assistant Detection', 800, 600)
                    cv2.imshow('Blind Assistant Detection', display_frame)
                    cv2.waitKey(1)  # This is required to actually display the frame
                    key = cv2.waitKey(1) & 0xFF
                    if key == ord('q'):
                        self.stop_event.set()
                except Exception as e:
                    logger.error(f"Error updating display: {e}")
                    self.show_gui = False
                    logger.info("Continuing without GUI...")
            
            return True
            
        except Exception as e:
            logger.error(f"Error processing frame: {e}")
            return False

    def run(self):
        """Run the main application loop."""
        try:
            logger.info("Starting Blind Assistant...")
            startup_message = (
                "Blind Assistant system is ready. "
                "The system will announce detected objects and their distances. "
                "Press Control+C to exit."
            )
            self.audio.speak_system_status(startup_message)
            
            # Main processing loop
            while not self.stop_event.is_set():
                if not self.process_frame():
                    logger.error("Failed to process frame, attempting to continue...")
                    continue
            
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
        finally:
            self.cleanup()

    def cleanup(self):
        """Clean up resources."""
        logger.info("Cleaning up resources...")
        self.audio.speak_system_status("System shutting down")
        
        # Release resources
        self.camera.release()
        self.audio.cleanup()
        
        if self.show_gui:
            try:
                cv2.destroyAllWindows()
            except:
                pass
        
        logger.info("Cleanup complete")

def main():
    """Main entry point for the application."""
    parser = argparse.ArgumentParser(description="Blind Assistant - Vision-based assistance system")
    parser.add_argument(
        "--config",
        type=str,
        default="config/settings.yaml",
        help="Path to configuration file"
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging"
    )
    parser.add_argument(
        "--no-gui",
        action="store_true",
        help="Disable GUI display"
    )
    args = parser.parse_args()

    # Initialize logging
    global logger
    logger = setup_logging(args.debug)

    try:
        # Check requirements before starting
        if not check_requirements():
            sys.exit(1)
            
        logger.info("System requirements check passed")
        assistant = BlindAssistant(config_path=args.config, show_gui=not args.no_gui)
        assistant.run()
    except Exception as e:
        logger.error(f"Failed to start Blind Assistant: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()