from .detector import ObjectDetector

__all__ = ['ObjectDetector']