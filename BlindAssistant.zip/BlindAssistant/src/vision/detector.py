from ultralytics import YOLO
import numpy as np
import cv2
from typing import List, Tuple, Dict
import yaml
import logging
from pathlib import Path
import torch

logger = logging.getLogger(__name__)

class ObjectDetector:
    """Handles object detection using YOLOv8."""
    
    def __init__(self, config_path: str = "config/settings.yaml"):
        """Initialize the object detector with configuration."""
        self.config = self._load_config(config_path)
        self.model_config = self.config["model"]
        self.detection_config = self.config["detection"]
        
        # Update device configuration based on availability
        self.device = self._determine_device()
        self.model_config["device"] = self.device
        logger.info(f"Using device: {self.device}")
        
        self.model = None
        self.initialize_model()

    def _load_config(self, config_path: str) -> dict:
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise

    def _determine_device(self) -> str:
        """Determine the appropriate device (CPU/CUDA) to use."""
        if torch.cuda.is_available():
            logger.info("CUDA is available, using GPU")
            return "cuda:0"  # Use first CUDA device
        else:
            logger.info("CUDA is not available, using CPU")
            return "cpu"

    def initialize_model(self) -> None:
        """Initialize the YOLO model."""
        try:
            model_path = self.model_config["model_path"]
            if not Path(model_path).exists():
                raise FileNotFoundError(f"Model file not found: {model_path}")
                
            logger.info(f"Loading YOLO model from {model_path} using device {self.device}")
            
            # Load the model directly, YOLO handles its own validation
            self.model = YOLO(model_path)
            self.model.to(self.device)  # Explicitly move model to device
            
            logger.info("Model loaded successfully")
                
        except Exception as e:
            logger.error(f"Failed to initialize YOLO model: {e}")
            raise

    def process_frame(self, frame: np.ndarray, depth_map: np.ndarray) -> List[Dict]:
        """Process a frame to detect objects and estimate their distances."""
        if self.model is None:
            logger.error("Model not initialized")
            return []
            
        try:
            # Run YOLO detection with predict method
            results = self.model.predict(
                source=frame,
                conf=self.model_config["confidence_threshold"],
                device=self.device,
                verbose=False
            )
            
            detections = []
            
            # Process detection results
            if len(results) > 0 and len(results[0].boxes) > 0:
                for box in results[0].boxes:
                    try:
                        # Get box coordinates
                        box_coords = box.xyxy[0].cpu().numpy()
                        class_id = int(box.cls[0])
                        confidence = float(box.conf[0])
                        
                        # Get object class name
                        class_name = results[0].names[class_id]
                        
                        # Calculate center point of bounding box
                        center_x = int((box_coords[0] + box_coords[2]) / 2)
                        center_y = int((box_coords[1] + box_coords[3]) / 2)
                        
                        # Get depth at center point of object
                        depth = self._get_object_depth(depth_map, center_x, center_y)
                        
                        # Calculate relative position
                        position = self._calculate_position(center_x, frame.shape[1])
                        
                        # Create detection entry
                        detection = {
                            'class': class_name,
                            'confidence': confidence,
                            'depth': depth,
                            'position': position,
                            'box': box_coords.tolist(),
                            'center': (center_x, center_y)
                        }
                        
                        detections.append(detection)
                        logger.debug(f"Detected {class_name} at position {position}, depth {depth:.2f}m, confidence {confidence:.2f}")
                    except Exception as e:
                        logger.error(f"Error processing detection: {e}")
                        continue
            
            # Sort detections by priority and confidence
            return self._prioritize_detections(detections)
            
        except Exception as e:
            logger.error(f"Error processing frame: {e}")
            return []

    def _get_object_depth(self, depth_map: np.ndarray, x: int, y: int) -> float:
        """Get the depth of an object from the depth map."""
        try:
            # Get depth from a small region around the point to reduce noise
            region_size = 5
            x1 = max(0, x - region_size)
            x2 = min(depth_map.shape[1], x + region_size)
            y1 = max(0, y - region_size)
            y2 = min(depth_map.shape[0], y + region_size)
            
            depth_region = depth_map[y1:y2, x1:x2]
            return float(np.median(depth_region))
        except Exception as e:
            logger.error(f"Error calculating depth: {e}")
            return 0.0

    def _calculate_position(self, x: int, frame_width: int) -> str:
        """Calculate relative position of object in frame."""
        try:
            relative_x = x / frame_width
            
            if relative_x < 0.33:
                return "left"
            elif relative_x > 0.67:
                return "right"
            else:
                return "center"
        except Exception as e:
            logger.error(f"Error calculating position: {e}")
            return "unknown"

    def _prioritize_detections(self, detections: List[Dict]) -> List[Dict]:
        """Prioritize detections based on configuration and distance."""
        try:
            priority_objects = self.detection_config["priority_objects"]
            max_objects = self.detection_config["max_objects"]
            min_distance = self.detection_config["minimum_distance"]
            max_distance = self.detection_config["maximum_distance"]
            
            # Filter by distance
            filtered_detections = [d for d in detections 
                                 if min_distance <= d['depth'] <= max_distance]
            
            # Sort by priority and confidence
            def priority_score(detection):
                # Higher score for priority objects
                priority_bonus = 2 if detection['class'] in priority_objects else 0
                # Higher score for closer objects
                distance_score = 1 / (detection['depth'] + 1)
                # Include confidence in scoring
                return priority_bonus + distance_score + detection['confidence']
            
            filtered_detections.sort(key=priority_score, reverse=True)
            
            # Log filtered detections
            if filtered_detections:
                logger.debug(f"Prioritized {len(filtered_detections)} detections from {len(detections)} total")
            
            # Limit number of detections
            return filtered_detections[:max_objects]
            
        except Exception as e:
            logger.error(f"Error prioritizing detections: {e}")
            return []

    def annotate_frame(self, frame: np.ndarray, detections: List[Dict]) -> np.ndarray:
        """Create an annotated copy of the frame for debugging purposes."""
        if not self.config["system"].get("save_debug_frames", False):
            return frame
            
        try:
            annotated = frame.copy()
            
            for detection in detections:
                box = detection['box']
                label = f"{detection['class']} ({detection['depth']:.1f}m)"
                
                # Draw bounding box
                cv2.rectangle(annotated,
                             (int(box[0]), int(box[1])),
                             (int(box[2]), int(box[3])),
                             (0, 255, 0),
                             2)
                
                # Draw label
                cv2.putText(annotated,
                           label,
                           (int(box[0]), int(box[1] - 10)),
                           cv2.FONT_HERSHEY_SIMPLEX,
                           0.5,
                           (0, 255, 0),
                           2)
            
            return annotated
        except Exception as e:
            logger.error(f"Error annotating frame: {e}")
            return frame