import pyttsx3
import platform
import sys
import time

def test_tts():
    """Test text-to-speech functionality with different engines."""
    print("Testing text-to-speech system...")
    print(f"Platform: {platform.system()}")
    print(f"Python version: {platform.python_version()}")
    
    try:
        # Try platform-specific initialization
        if platform.system() == 'Windows':
            print("\nTesting with SAPI5 (Windows)...")
            engine = pyttsx3.init('sapi5')
        elif platform.system() == 'Darwin':
            print("\nTesting with NSSpeechSynthesizer (macOS)...")
            engine = pyttsx3.init('nsss')
        else:
            print("\nTesting with eSpeak (Linux/Other)...")
            engine = pyttsx3.init('espeak')
        
        # Get and display available voices
        voices = engine.getProperty('voices')
        print(f"\nFound {len(voices)} voices:")
        for voice in voices:
            print(f"- {voice.name} ({voice.id})")
            print(f"  Languages: {voice.languages}")
        
        # Test speech
        print("\nTesting speech output...")
        test_messages = [
            "This is a test of the text to speech system.",
            "Testing different directions: left, right, and center.",
            "Testing numbers: 1, 2, 3, 4, 5.",
            "Testing distances: 5 feet away, 10 meters ahead."
        ]
        
        for msg in test_messages:
            print(f"\nSpeaking: {msg}")
            engine.say(msg)
            engine.runAndWait()
            time.sleep(1)
        
        # Test different rates
        print("\nTesting different speech rates...")
        rates = [50, 100, 150, 200]
        for rate in rates:
            print(f"Testing rate: {rate}")
            engine.setProperty('rate', rate)
            engine.say(f"This is speech rate {rate}")
            engine.runAndWait()
            time.sleep(1)
        
        # Test different volumes
        print("\nTesting different volumes...")
        volumes = [0.3, 0.6, 1.0]
        for vol in volumes:
            print(f"Testing volume: {vol}")
            engine.setProperty('volume', vol)
            engine.say(f"This is volume level {int(vol * 100)} percent")
            engine.runAndWait()
            time.sleep(1)
        
        print("\nAudio test completed successfully!")
        return True
        
    except Exception as e:
        print(f"\nError testing text-to-speech: {str(e)}")
        print("\nTroubleshooting steps:")
        print("1. Ensure speakers/headphones are connected and working")
        print("2. Check system volume and unmute if necessary")
        print("3. Try reinstalling pyttsx3:")
        print("   pip uninstall pyttsx3")
        print("   pip install pyttsx3")
        if platform.system() == 'Windows':
            print("4. Check Windows speech settings:")
            print("   - Open Windows Settings -> Time & Language -> Speech")
            print("   - Ensure a speech language is installed")
        elif platform.system() == 'Linux':
            print("4. Install espeak if not present:")
            print("   sudo apt-get install espeak")
        return False

if __name__ == "__main__":
    print("Text-to-Speech Test Utility")
    print("==========================")
    success = test_tts()
    sys.exit(0 if success else 1)